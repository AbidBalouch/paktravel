// app/page.js
import Banner from "@/components/Banner/Banner";
import BrandsCarousel from "@/components/BrandsCarousel/BrandsCarousel";
import Destinations from "@/components/Destinations/Destinations";

export default function HomePage() {
  return (
    <>
      <Banner />
      <BrandsCarousel />
      <Destinations />
      {/* Aage aap next sections yahan add karte jayen, jaise:
          <Attractions />, <TravelPoint />, waghera — jaise jaise
          image + JSON milta jaye, waise waise component banate jayenge. */}
    </>
  );
}
