// app/layout.js
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import Header from "@/components/Header/Header";
import Footer from "@/components/Footer/Footer";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700", "800"],
  variable: "--font-plus-jakarta",
  display: "swap",
});

export const metadata = {
  title: "Travel Pakistan",
  description:
    "Discover the beauty of Pakistan with curated destinations, local experiences, and seamless travel planning.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      {/* suppressHydrationWarning: browser extensions (ColorZilla waghera)
          body tag me apna attribute inject kar dete hain jiski wajah se
          hydration mismatch warning aati hai — humare code ka bug nahi. */}
      <body className={plusJakarta.variable} suppressHydrationWarning>
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
