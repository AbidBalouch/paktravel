// components/Footer/Footer.jsx
// Server component — koi client interactivity nahi chahiye isliye
// seedha yahin data fetch aur render kar dete hain.

import Image from "next/image";
import { getFooterData } from "@/lib/api";
import styles from "./Footer.module.css";

// Chhote inline social icons — extra icon library ki zaroorat nahi
const SOCIAL_ICONS = {
  facebook: (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
      <path d="M22 12a10 10 0 1 0-11.6 9.9v-7H7.9V12h2.5V9.8c0-2.5 1.5-3.9 3.8-3.9 1.1 0 2.2.2 2.2.2v2.4h-1.3c-1.2 0-1.6.8-1.6 1.6V12h2.8l-.4 2.9h-2.4v7A10 10 0 0 0 22 12Z" />
    </svg>
  ),
  twitter: (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
      <path d="M22 5.9c-.7.3-1.5.6-2.3.7a4 4 0 0 0 1.8-2.2 8 8 0 0 1-2.5 1 4 4 0 0 0-6.9 3.6A11.4 11.4 0 0 1 3.9 4.9a4 4 0 0 0 1.3 5.4c-.6 0-1.2-.2-1.7-.5v.1a4 4 0 0 0 3.2 4 4 4 0 0 1-1.8.1 4 4 0 0 0 3.8 2.8A8.1 8.1 0 0 1 2 18.4a11.4 11.4 0 0 0 6.2 1.8c7.4 0 11.5-6.2 11.5-11.5v-.5c.8-.6 1.5-1.3 2.3-2.2Z" />
    </svg>
  ),
  instagram: (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
      <path d="M12 2c2.7 0 3.1 0 4.1.1 1.1 0 1.8.2 2.5.5a5 5 0 0 1 1.8 1.2 5 5 0 0 1 1.2 1.8c.3.7.5 1.4.5 2.5.1 1 .1 1.4.1 4.1s0 3.1-.1 4.1c0 1.1-.2 1.8-.5 2.5a5 5 0 0 1-1.2 1.8 5 5 0 0 1-1.8 1.2c-.7.3-1.4.5-2.5.5-1 .1-1.4.1-4.1.1s-3.1 0-4.1-.1c-1.1 0-1.8-.2-2.5-.5a5 5 0 0 1-1.8-1.2 5 5 0 0 1-1.2-1.8c-.3-.7-.5-1.4-.5-2.5C2 15.1 2 14.7 2 12s0-3.1.1-4.1c0-1.1.2-1.8.5-2.5a5 5 0 0 1 1.2-1.8 5 5 0 0 1 1.8-1.2c.7-.3 1.4-.5 2.5-.5C8.9 2 9.3 2 12 2Zm0 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Zm5.2-2.7a1.2 1.2 0 1 1 0 2.4 1.2 1.2 0 0 1 0-2.4Z" />
    </svg>
  ),
};

export default async function Footer() {
  const data = await getFooterData();

  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.top}`}>
        {/* Brand column */}
        <div className={styles.brand}>
          <div className={styles.brandHeading}>
            {data.brand?.logo && (
              <Image
                src={data.brand.logo}
                alt="Travel Pakistan"
                width={140}
                height={26}
                className={styles.brandLogo}
              />
            )}
          </div>
          <p className={styles.brandDesc}>{data.brand?.description}</p>

          <p className={styles.downloadTitle}>{data.download_app?.title}</p>
          <div className={styles.storeButtons}>
            {data.download_app?.app_store_url && (
              <a
                href={data.download_app.app_store_url}
                className={styles.storeBtn}
                target="_blank"
                rel="noopener noreferrer"
              >
                <span className={styles.storeBtnSmall}>Download on the</span>
                <span className={styles.storeBtnBig}>App Store</span>
              </a>
            )}
            {data.download_app?.google_play_url && (
              <a
                href={data.download_app.google_play_url}
                className={styles.storeBtn}
                target="_blank"
                rel="noopener noreferrer"
              >
                <span className={styles.storeBtnSmall}>GET IT ON</span>
                <span className={styles.storeBtnBig}>Google Play</span>
              </a>
            )}
          </div>
        </div>

        {/* Menu columns — WordPress se jitne bhi menus aayen, sab dynamically render honge */}
        <div className={styles.menus}>
          {data.menus?.map((menu) => (
            <div key={menu.menu_id} className={styles.menuCol}>
              <h4 className={styles.menuTitle}>{menu.title}</h4>
              <ul>
                {menu.items?.map((item) => (
                  <li key={item.id}>
                    <a href={item.url} target={item.target || "_self"}>
                      {item.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Social bar */}
      <div className={styles.socialBar}>
        <div className={`container ${styles.socialInner}`}>
          {data.socials?.map((social) => (
            <a
              key={social.platform}
              href={social.url}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={social.platform}
              className={styles.socialIcon}
            >
              {SOCIAL_ICONS[social.icon] || social.platform.charAt(0)}
            </a>
          ))}
        </div>
      </div>
    </footer>
  );
}
