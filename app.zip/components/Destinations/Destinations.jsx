// components/Destinations/Destinations.jsx
// ---------------------------------------------------------------------------
// Server component — home page ACF se badge/heading pick karta hai aur
// "destination" custom post type se actual destination cards fetch karta
// hai.
//
// LAYOUT (exact reference design ke mutabiq):
//   Row 1 -> [ featured (2 columns wide) ][ normal card ][ normal card ]
//   Row 2 -> [ normal ][ normal ][ normal ][ normal ]   (4 equal cards)
//
// Ye ek hi 4-column CSS grid se ban raha hai — featured card sirf
// "grid-column: span 2" leta hai, baqi sab cards normal 1-column cards
// hain. Grid ka auto-placement khud row 2 me 4 cards fit kar deta hai,
// isliye alag se "row 1 / row 2" manually define karne ki zaroorat nahi.
// ---------------------------------------------------------------------------

import Image from "next/image";
import { getDestinationsData } from "@/lib/api";
import styles from "./Destinations.module.css";

export default async function Destinations() {
  const data = await getDestinationsData();

  // Featured + baqi items ko ek hi list me combine kar dete hain —
  // pehla item hamesha featured (bada) card hoga.
  const cards = data.featured ? [data.featured, ...data.items] : data.items;

  if (cards.length === 0) return null;

  return (
    <section className={styles.section}>
      <div className={`container ${styles.inner}`}>
        {data.badge && <span className={styles.badge}>{data.badge}</span>}
        {data.heading && <h2 className={styles.heading}>{data.heading}</h2>}

        <div className={styles.grid}>
          {cards.map((item, index) => {
            const isFeatured = index === 0;

            return (
              <a
                href={item.link}
                key={item.id}
                className={`${styles.card} ${isFeatured ? styles.featuredCard : ""}`}
                aria-label={item.title}
              >
                {item.image && (
                  <Image
                    src={item.image}
                    alt={item.alt}
                    fill
                    sizes={
                      isFeatured
                        ? "(max-width: 900px) 100vw, 50vw"
                        : "(max-width: 900px) 50vw, 25vw"
                    }
                    className={styles.cardImage}
                    priority={isFeatured}
                  />
                )}
                <div className={styles.cardOverlay} />
                <div className={styles.cardText}>
                  <h3>{item.title}</h3>
                  <p>{item.excerpt}</p>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
}
