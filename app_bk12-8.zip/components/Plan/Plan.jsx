// components/Plan/Plan.jsx
// Server component — "Why plan here" section (home page ACF se).

import Image from "next/image";
import { getPlanData } from "@/lib/api";
import styles from "./Plan.module.css";

export default async function Plan() {
  const data = await getPlanData();

  return (
    <section className={styles.section}>
      <div className={`container ${styles.inner}`}>
        {/* ---------- Left: content + feature list ---------- */}
        <div className={styles.content}>
          {data.badge && <span className={styles.badge}>{data.badge}</span>}

          {/* plan_heading admin se plain text aata hai, lekin future me
              <span> allow karne ke liye HTML render kar rahe hain */}
          {data.heading && (
            <h2
              className={styles.heading}
              dangerouslySetInnerHTML={{ __html: data.heading }}
            />
          )}

          {data.description && (
            <p className={styles.description}>{data.description}</p>
          )}

          <ul className={styles.list}>
            {data.items.map((item) => (
              <li key={item.key} className={styles.listItem}>
                <span className={styles.iconBox}>
                  {item.icon?.url && (
                    <Image
                      src={item.icon.url}
                      alt={item.icon.alt || item.title}
                      width={24}
                      height={24}
                      className={styles.icon}
                    />
                  )}
                </span>
                <div>
                  <h3 className={styles.itemTitle}>{item.title}</h3>
                  {item.description && (
                    <p className={styles.itemText}>{item.description}</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>

        {/* ---------- Right: image + decorative shapes ---------- */}
        <div className={styles.media}>
          {/* Ye dono purely decorative hain (arc + dotted grid),
              API se in ka koi data nahi aata — CSS se banaye hain */}
          <span className={styles.arc} aria-hidden="true" />
          <span className={styles.dots} aria-hidden="true" />

          {data.image?.url && (
            <Image
              src={data.image.url}
              alt={data.image.alt || "Plan your trip"}
              width={620}
              height={520}
              className={styles.image}
            />
          )}
        </div>
      </div>
    </section>
  );
}
