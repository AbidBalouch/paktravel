"use client";
// components/FilterBar/FilterBar.jsx
// ---------------------------------------------------------------------------
// Simplified version — sirf 3 native <select> dropdowns:
//   1) Category — item.category (taxonomy term, e.g. "Mosque"/"Hotel") se
//   2) Type     — filhaal isi field se (WordPress mein sirf ek hi
//                 classification taxonomy hai har post pe). Agar "Type"
//                 kisi alag field ko represent karna chahiye, batayein,
//                 alag data source wire kar denge.
//   3) Order By — sorting: Rating, Price, Name
//
// Koi "Apply"/"Clear"/"Recommended" button nahi — select change hote hi
// turant filter/sort lag jata hai (jaisa native <select> se expect hota hai).
// ---------------------------------------------------------------------------

import { useState, useMemo } from "react";
import styles from "./FilterBar.module.css";

const SORT_OPTIONS = [
  { value: "default", label: "Order By: Recommended" },
  { value: "rating_desc", label: "Rating: High to Low" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
  { value: "name_asc", label: "Name: A–Z" },
];

export default function FilterBar({ items = [], onChange }) {
  const categoryOptions = useMemo(
    () => [...new Set(items.map((i) => i.category).filter(Boolean))],
    [items]
  );

  const [category, setCategory] = useState("");
  const [type, setType] = useState("");
  const [sortBy, setSortBy] = useState("default");

  function update(partial) {
    const next = {
      category: partial.category ?? category,
      type: partial.type ?? type,
      sortBy: partial.sortBy ?? sortBy,
    };
    setCategory(next.category);
    setType(next.type);
    setSortBy(next.sortBy);
    onChange(next);
  }

  return (
    <div className={styles.bar}>
      <select
        className={styles.select}
        value={category}
        onChange={(e) => update({ category: e.target.value })}
        aria-label="Filter by category"
      >
        <option value="">Category: All</option>
        {categoryOptions.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>

      <select
        className={styles.select}
        value={type}
        onChange={(e) => update({ type: e.target.value })}
        aria-label="Filter by type"
      >
        <option value="">Type: All</option>
        {categoryOptions.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>

      <select
        className={styles.select}
        value={sortBy}
        onChange={(e) => update({ sortBy: e.target.value })}
        aria-label="Order by"
      >
        {SORT_OPTIONS.map((opt) => (
          <option key={opt.value} value={opt.value}>
            {opt.label}
          </option>
        ))}
      </select>
    </div>
  );
}
