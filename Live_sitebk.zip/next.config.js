/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "hammada154.sg-host.com",
      },
    ],
  },
};

module.exports = nextConfig;
